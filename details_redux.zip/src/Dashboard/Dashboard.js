
import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import './Dashboard.css';
const Dashboard = () => {
  const userName = useSelector(state => state.user.name);
  console.log(userName);

  return (
    <div className='dashboard-body'>
      <div className='dashboard-content'>Hello {userName}</div>
      <Link to="/profile"><h4>Go to Profile</h4></Link>
    </div>
  );
};

export default Dashboard;
